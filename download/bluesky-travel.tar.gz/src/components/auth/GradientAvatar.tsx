"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { cn, initials } from "@/lib/utils";

interface GradientAvatarProps {
  name?: string;
  email?: string;
  imageUrl?: string;
  /** Pixel size — defaults to 40 (responsive navbar sizing handled by parent). */
  size?: number;
  /** Show the green online indicator dot. */
  showOnline?: boolean;
  className?: string;
  /** Click handler — when provided, the avatar gets hover scale + cursor-pointer. */
  onClick?: () => void;
  interactive?: boolean;
}

/**
 * Premium circular avatar — used in the Navbar after login.
 *
 * - If `imageUrl` is provided, displays the profile image (object-cover, rounded-full).
 * - Otherwise generates a deterministic BlueSky gradient avatar with the user's initials.
 * - Optional green online indicator dot at the bottom-right.
 * - Hover scales up subtly when `interactive` is true (cursor-pointer + ring).
 *
 * Sizes (per spec): 48px desktop, 40px tablet, 36px mobile — passed via `size` prop
 * by the parent using responsive Tailwind classes.
 */
export function GradientAvatar({
  name,
  email,
  imageUrl,
  size = 40,
  showOnline = true,
  className,
  onClick,
  interactive = false,
}: GradientAvatarProps) {
  const label = initials(name || email);
  // Deterministic hue based on the name so the same user always gets the same gradient.
  const hue = (name || email || "BS")
    .split("")
    .reduce((acc, ch) => acc + ch.charCodeAt(0), 0) % 60;
  const gradient = `linear-gradient(135deg, hsl(${210 + hue} 85% 55%) 0%, hsl(${200 + hue} 90% 60%) 50%, hsl(${190 + hue} 85% 65%) 100%)`;

  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={interactive ? { scale: 1.06 } : undefined}
      whileTap={interactive ? { scale: 0.96 } : undefined}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      aria-label={name ? `Account: ${name}` : "Account"}
      className={cn(
        "relative grid shrink-0 place-items-center rounded-full ring-2 ring-white/70 shadow-premium",
        interactive && "cursor-pointer hover:ring-primary/40",
        className,
      )}
      style={{ width: size, height: size, background: imageUrl ? undefined : gradient }}
    >
      {imageUrl ? (
        <Image
          src={imageUrl}
          alt={name || "User avatar"}
          fill
          sizes={`${size}px`}
          className="rounded-full object-cover"
        />
      ) : (
        <span
          className="font-bold text-white"
          style={{ fontSize: Math.round(size * 0.36) }}
        >
          {label}
        </span>
      )}

      {showOnline && (
        <span
          className="absolute bottom-0 right-0 grid place-items-center rounded-full bg-emerald-500 ring-2 ring-white"
          style={{ width: Math.max(8, Math.round(size * 0.22)), height: Math.max(8, Math.round(size * 0.22)) }}
        >
          <span className="size-1.5 rounded-full bg-white/90" />
        </span>
      )}
    </motion.button>
  );
}
